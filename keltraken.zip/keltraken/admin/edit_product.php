<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file
include '../connection/db.php';

// Check if the product ID is provided in the GET request
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: admin.php');
    exit();
}

$product_id = $_GET['id'];

// Fetch the product data from the database
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    echo '<p class="bg-red-500 text-white p-2">Product not found.</p>';
    exit();
}

// Handle update requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
    $image_url = $_POST['image_url'];

    // Update the product in the database
    $update_query = "UPDATE products SET name = ?, price = ?, description = ?, quantity_in_stock = ?, image_url = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('sdsisi', $name, $price, $description, $quantity, $image_url, $product_id);
    if ($stmt->execute()) {
        echo '<p class="bg-green-500 text-white p-2">Product updated successfully!</p>';
    } else {
        echo '<p class="bg-red-500 text-white p-2">Failed to update product.</p>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-800">

    <section class="py-16">
        <div class="container mx-auto">
            <h2 class="text-2xl font-bold mb-6">Edit Product: <?= htmlspecialchars($product['name']); ?></h2>

            <form method="POST" class="bg-white p-6 shadow-md rounded-lg">
                <div class="mb-4">
                    <label for="name" class="block text-gray-700">Name</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($product['name']); ?>" class="w-full px-4 py-2 border rounded-lg">
                </div>

                <div class="mb-4">
                    <label for="price" class="block text-gray-700">Price (₦)</label>
                    <input type="text" id="price" name="price" value="<?= number_format($product['price'] * 775, 2); ?>" class="w-full px-4 py-2 border rounded-lg">
                </div>

                <div class="mb-4">
                    <label for="description" class="block text-gray-700">Description</label>
                    <textarea id="description" name="description" class="w-full px-4 py-2 border rounded-lg"><?= htmlspecialchars($product['description']); ?></textarea>
                </div>

                <div class="mb-4">
                    <label for="quantity" class="block text-gray-700">Quantity</label>
                    <input type="number" id="quantity" name="quantity" value="<?= $product['quantity_in_stock']; ?>" class="w-full px-4 py-2 border rounded-lg">
                </div>

                <div class="mb-4">
                    <label for="image_url" class="block text-gray-700">Image URL</label>
                    <input type="text" id="image_url" name="image_url" value="<?= htmlspecialchars($product['image_url']); ?>" class="w-full px-4 py-2 border rounded-lg">
                </div>

                <button type="submit" name="update_product" class="bg-green-600 text-white px-4 py-2 rounded-lg">Update Product</button>
            </form>
        </div>
    </section>

</body>
</html>
