<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file
include '../connection/db.php';

// Check if the user is an admin (you should implement admin checks here)
// if (!isset($_SESSION['admin'])) {
//     header('Location: ../authentication/login.php');
//     exit();
// }

// Handle update requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_product'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
    $image_url = $_POST['image_url'];

    // Update the product in the database
    $update_query = "UPDATE products SET name = ?, price = ?, description = ?, quantity_in_stock = ?, image_url = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('sdsisi', $name, $price, $description, $quantity, $image_url, $id);
    if ($stmt->execute()) {
        echo '<p class="bg-green-500 text-white p-2">Product updated successfully!</p>';
    } else {
        echo '<p class="bg-red-500 text-white p-2">Failed to update product.</p>';
    }
}

// Query to fetch all products
$sql = "SELECT id, name, price, description, quantity_in_stock, image_url FROM products";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Manage Products</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-800">

    <header class="bg-white shadow-md">
        <div class="container mx-auto p-4">
            <h1 class="text-2xl font-bold text-green-700">Admin - Manage Products</h1>
        </div>
    </header>

    <section class="py-16">
        <div class="container mx-auto">
            <h2 class="text-2xl font-bold mb-6">Product List</h2>

            <!-- Display all products in a table with editable fields -->
            <table class="w-full bg-white shadow-md rounded-lg">
                <thead>
                    <tr class="bg-green-600 text-white">
                        <th class="p-4 text-left">ID</th>
                        <th class="p-4 text-left">Name</th>
                        <th class="p-4 text-left">Price (₦)</th>
                        <th class="p-4 text-left">Description</th>
                        <th class="p-4 text-left">Quantity</th>
                        <th class="p-4 text-left">Image</th>
                        <th class="p-4 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '
                            <tr class="border-b">
                                <td class="p-4">' . $row['id'] . '</td>
                                
                                <!-- Editable fields for name, price, description, quantity, and image URL -->
                                <form method="POST" action="admin.php">
                                    <td class="p-4">
                                        <input type="text" name="name" value="' . htmlspecialchars($row['name']) . '" class="w-full px-2 py-1 border rounded-lg">
                                    </td>
                                    <td class="p-4">
                                        <input type="text" name="price" value="' . number_format($row['price'], 2) . '" class="w-full px-2 py-1 border rounded-lg">
                                    </td>
                                    <td class="p-4">
                                        <textarea name="description" class="w-full px-2 py-1 border rounded-lg">' . htmlspecialchars($row['description']) . '</textarea>
                                    </td>
                                    <td class="p-4">
                                        <input type="number" name="quantity" value="' . $row['quantity_in_stock'] . '" class="w-full px-2 py-1 border rounded-lg">
                                    </td>
                                    <td class="p-4">
                                        <input type="text" name="image_url" value="' . htmlspecialchars($row['image_url']) . '" class="w-full px-2 py-1 border rounded-lg">
                                    </td>
                                    
                                    <!-- Hidden input to pass the product ID -->
                                    <input type="hidden" name="id" value="' . $row['id'] . '">

                                    <td class="p-4">
                                        <button type="submit" name="update_product" class="bg-blue-600 text-white px-4 py-2 rounded-lg">Save</button>
                                    </td>
                                </form>
                            </tr>';
                        }
                    } else {
                        echo '<tr><td colspan="7" class="p-4 text-center">No products found.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
