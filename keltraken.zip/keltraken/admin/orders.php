<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file and PHPMailer
include '../connection/db.php';
require '../connection/vendor/autoload.php'; // Assuming you've installed PHPMailer via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to send email notification
function sendStatusUpdateEmail($shipping_email, $order_id, $new_status) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'mail.keltrakenfarms.ng';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'orders@keltrakenfarms.ng';
        $mail->Password   = 'NL-wJVXbR@&y';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // Recipients
        $mail->setFrom('orders@keltrakenfarms.ng', 'Keltraken Farms');
        $mail->addAddress($shipping_email); // Add the recipient's email address

        // Content
        $mail->isHTML(true);
        $mail->Subject = "Order #{$order_id} Status Update";
        $mail->Body    = "Dear customer,<br><br>Your order #{$order_id} has been updated to: <strong>{$new_status}</strong>.<br>Thank you for shopping with Keltraken Farms!<br><br>Best regards,<br>Keltraken Farms Team";

        $mail->send();
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }
}

// Update order status if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id']) && isset($_POST['order_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['order_status'];

    // Fetch the order to get the shipping email
    $order_query = $conn->prepare("SELECT shipping_email FROM user_addresses WHERE user_id = (SELECT user_id FROM orders_master WHERE order_id = ?)");
    $order_query->bind_param("i", $order_id);
    $order_query->execute();
    $order_result = $order_query->get_result();
    $order = $order_result->fetch_assoc();
    $shipping_email = $order['shipping_email'];

    // Update the order status in the database
    $update_status_query = $conn->prepare("UPDATE orders_master SET status = ? WHERE order_id = ?");
    $update_status_query->bind_param("si", $new_status, $order_id);
    $update_status_query->execute();

    // Send email notification
    sendStatusUpdateEmail($shipping_email, $order_id, $new_status);
}

// Fetch all orders from the orders_master table
$orders_query = $conn->prepare("
    SELECT orders_master.order_id, orders_master.user_id, orders_master.order_date, orders_master.status, orders_master.receipt_path, 
           user_addresses.billing_fullname, user_addresses.billing_email, user_addresses.billing_phone, 
           user_addresses.shipping_fullname, user_addresses.shipping_email, user_addresses.shipping_phone
    FROM orders_master
    JOIN user_addresses ON orders_master.user_id = user_addresses.user_id
    ORDER BY orders_master.order_date DESC
");
$orders_query->execute();
$orders_result = $orders_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Orders | Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .order-list-item {
            border: 1px solid #ccc;
            padding: 16px;
            margin-bottom: 12px;
            border-radius: 8px;
            background-color: #fff;
        }
        .order-list-item h3 {
            font-size: 1.25rem;
            font-weight: bold;
        }
        .status-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 12px;
        }
        .status-bar div {
            flex: 1;
            padding: 10px;
            text-align: center;
            color: #fff;
            font-weight: bold;
            border-radius: 5px;
        }
        .status-pending { background-color: #ff9800; }
        .status-confirmed { background-color: #4caf50; }
        .status-shipping { background-color: #2196f3; }
        .status-delivered { background-color: #9c27b0; }
        .status-inactive { background-color: #ccc; }
        .receipt-view { margin-top: 10px; }
    </style>
</head>

<body class="bg-gray-100 text-gray-800">

    <!-- Header Section -->
    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center p-4">
            <div class="flex items-center space-x-4">
                <img src="../KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
                <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms Admin</h1>
            </div>
            <a href="logout.php" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">Log Out</a>
        </div>
    </header>

    <!-- Orders Section -->
    <section class="py-16">
        <div class="container mx-auto">
            <h2 class="text-3xl font-bold mb-6">All Orders</h2>

            <!-- Display all orders -->
            <?php if ($orders_result->num_rows > 0): ?>
                <div class="order-list">
                    <?php while ($order = $orders_result->fetch_assoc()): ?>
                        <div class="order-list-item">
                            <h3>Order #<?= $order['order_id']; ?></h3>
                            <p><strong>Order Date:</strong> <?= date("F j, Y, g:i a", strtotime($order['order_date'])); ?></p>
                            <p><strong>Billing Name:</strong> <?= htmlspecialchars($order['billing_fullname']); ?></p>
                            <p><strong>Billing Email:</strong> <?= htmlspecialchars($order['billing_email']); ?></p>
                            <p><strong>Billing Phone:</strong> <?= htmlspecialchars($order['billing_phone']); ?></p>
                            <p><strong>Shipping Name:</strong> <?= htmlspecialchars($order['shipping_fullname']); ?></p>
                            <p><strong>Shipping Email:</strong> <?= htmlspecialchars($order['shipping_email']); ?></p>
                            <p><strong>Shipping Phone:</strong> <?= htmlspecialchars($order['shipping_phone']); ?></p>

                            <!-- Fetch order items for this order -->
                            <?php
                            $order_items_query = $conn->prepare("
                                SELECT products.name, products.price, order_items.quantity 
                                FROM order_items 
                                JOIN products ON order_items.product_id = products.id 
                                WHERE order_items.order_id = ?
                            ");
                            $order_items_query->bind_param("i", $order['order_id']);
                            $order_items_query->execute();
                            $order_items_result = $order_items_query->get_result();
                            ?>

                            <h4 class="mt-4 mb-2 text-lg font-semibold">Items in this Order:</h4>
                            <ul class="list-disc ml-5">
                                <?php while ($item = $order_items_result->fetch_assoc()): ?>
                                    <li>
                                        <p><strong>Product:</strong> <?= htmlspecialchars($item['name']); ?></p>
                                        <p><strong>Quantity:</strong> <?= $item['quantity']; ?></p>
                                        <p><strong>Price:</strong> ₦<?= number_format($item['price'], 2); ?></p>
                                    </li>
                                <?php endwhile; ?>
                            </ul>

                            <!-- Uploaded Receipt View -->
                            <?php if (!empty($order['receipt_path'])): ?>
                                <div class="receipt-view">
                                    <p><strong>Uploaded Receipt:</strong></p>
                                    <a href="<?= htmlspecialchars('../process/' . $order['receipt_path']); ?>" target="_blank" class="text-blue-600 underline">
                                        View Receipt
                                    </a>
                                </div>
                            <?php endif; ?>

                            <!-- Status Bar (Updateable) -->
                            <form method="POST" action="">
                                <div class="status-bar mt-4">
                                    <div class="<?= $order['status'] === 'pending' ? 'status-pending' : 'status-inactive'; ?>">
                                        Pending Payment
                                    </div>
                                    <div class="<?= $order['status'] === 'confirmed' ? 'status-confirmed' : ($order['status'] !== 'pending' ? 'status-inactive' : ''); ?>">
                                        Payment Confirmed
                                    </div>
                                    <div class="<?= $order['status'] === 'shipping' ? 'status-shipping' : ($order['status'] === 'delivered' || $order['status'] === 'confirmed' ? 'status-inactive' : ''); ?>">
                                        Shipping
                                    </div>
                                    <div class="<?= $order['status'] === 'delivered' ? 'status-delivered' : 'status-inactive'; ?>">
                                        Delivered
                                    </div>
                                </div>

                                <!-- Status Update Dropdown -->
                                <div class="mt-4">
                                    <label for="order_status" class="block font-semibold">Update Status:</label>
                                    <select name="order_status" id="order_status" class="w-full p-2 mt-2 border rounded-lg">
                                        <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : ''; ?>>Pending Payment</option>
                                        <option value="confirmed" <?= $order['status'] === 'confirmed' ? 'selected' : ''; ?>>Payment Confirmed</option>
                                        <option value="shipping" <?= $order['status'] === 'shipping' ? 'selected' : ''; ?>>Shipping</option>
                                        <option value="delivered" <?= $order['status'] === 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                    </select>
                                    <input type="hidden" name="order_id" value="<?= $order['order_id']; ?>">
                                    <button type="submit" class="mt-4 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                                        Update Status
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-center text-gray-700">No orders have been placed yet.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-green-800 text-white py-10">
        <div class="container mx-auto text-center">
            <p>&copy; YY Organizations. All Rights Reserved.</p>
        </div>
    </footer>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
