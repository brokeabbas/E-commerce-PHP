<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file
include '../connection/db.php';

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login");
    exit();
}

// Get the logged-in user's ID and username
$username = $_SESSION['username'];
$user_query = $conn->prepare("SELECT id, username FROM users WHERE username = ?");
$user_query->bind_param("s", $username);
$user_query->execute();
$user_result = $user_query->get_result();
$user = $user_result->fetch_assoc();
$user_id = $user['id'];

// Handle username change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_username'])) {
    $new_username = trim($_POST['new_username']);

    // Check if the username is already taken
    $check_username_query = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check_username_query->bind_param("s", $new_username);
    $check_username_query->execute();
    $check_username_result = $check_username_query->get_result();

    if ($check_username_result->num_rows > 0) {
        $error_message = "Username already taken. Please choose another.";
    } else {
        // Update the username
        $update_username_query = $conn->prepare("UPDATE users SET username = ? WHERE id = ?");
        $update_username_query->bind_param("si", $new_username, $user_id);
        if ($update_username_query->execute()) {
            $_SESSION['username'] = $new_username; // Update session username
            $success_message = "Username updated successfully.";
        } else {
            $error_message = "Failed to update username. Please try again.";
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'], $_POST['confirm_password'])) {
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Check if passwords match
    if ($new_password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } else {
        // Hash the new password and update it in the database
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        $update_password_query = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $update_password_query->bind_param("si", $hashed_password, $user_id);
        if ($update_password_query->execute()) {
            $success_message = "Password updated successfully.";
        } else {
            $error_message = "Failed to update password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-800">

    <!-- Header Section -->
    <header class="bg-white shadow sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center p-4">
            <div class="flex items-center space-x-4">
                <img src="../KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
                <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms</h1>
            </div>
            <div class="flex items-center space-x-4">
                <span class="text-green-600">Hello, <?= htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout">
                    <button class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                        Log Out
                    </button>
                </a>
            </div>
        </div>
    </header>

    <!-- Profile Section -->
    <section class="py-12">
        <div class="container mx-auto max-w-4xl">
            <h2 class="text-3xl font-bold mb-8 text-center">User Profile</h2>

            <!-- Success/Error Message -->
            <?php if (isset($success_message)): ?>
                <p class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?= $success_message; ?></p>
            <?php elseif (isset($error_message)): ?>
                <p class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?= $error_message; ?></p>
            <?php endif; ?>

            <!-- Profile Overview -->
            <div class="bg-white p-6 rounded-lg shadow-md mb-8">
                <h3 class="text-xl font-semibold mb-4">Profile Overview</h3>
                <p><strong>Username:</strong> <?= htmlspecialchars($user['username']); ?></p>
            </div>

            <!-- Profile Options -->
            <div class="grid grid-cols-1 gap-8 md:grid-cols-3">
                <!-- View Orders Link -->
                <div class="bg-white p-6 rounded-lg shadow-md text-center">
                    <h4 class="text-lg font-semibold mb-4">My Orders</h4>
                    <a href="../process/orders" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200 inline-block">
                        View Orders
                    </a>
                </div>

                <!-- Change Username Form -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h4 class="text-lg font-semibold mb-4">Change Username</h4>
                    <form action="" method="POST">
                        <label for="new_username" class="block text-sm font-medium mb-2">New Username</label>
                        <input type="text" name="new_username" id="new_username" class="w-full p-2 border rounded mb-4" required>
                        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition duration-200 w-full">
                            Update Username
                        </button>
                    </form>
                </div>

                <!-- Change Password Form -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h4 class="text-lg font-semibold mb-4">Change Password</h4>
                    <form action="" method="POST">
                        <label for="new_password" class="block text-sm font-medium mb-2">New Password</label>
                        <input type="password" name="new_password" id="new_password" class="w-full p-2 border rounded mb-4" required>
                        
                        <label for="confirm_password" class="block text-sm font-medium mb-2">Confirm Password</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="w-full p-2 border rounded mb-4" required>
                        
                        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200 w-full">
                            Update Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-green-800 text-white py-6">
        <div class="container mx-auto text-center text-sm">
            <p>&copy; YY Organizations. All Rights Reserved.</p>
        </div>
    </footer>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
