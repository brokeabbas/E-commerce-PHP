<?php
// Start the session
session_start();

// Include the database connection file
include 'connection/db.php';

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['username']);
if ($isLoggedIn) {
    $username = $_SESSION['username']; // Store the username if logged in
}

// Fetch random products from multiple categories
$sql = "
    SELECT name, price, description, image_url, category_id 
    FROM products 
    WHERE category_id IN (1, 2, 3, 4) -- Assuming 1, 2, 3, 4 are category IDs
    ORDER BY RAND() 
    LIMIT 4"; // Fetching 4 random products
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <style>
        /* Hero Section Background */
        .hero {
            background-image: url('bg1.webp');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        /* Animation styles */
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fadeInDown {
            animation: fadeInDown 0.8s ease-out forwards;
        }

        .animate-fadeInUp {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        /* Custom section styling */
        .how-we-started {
            background-color: #f5f5f5;
            padding: 60px 20px;
            text-align: center;
        }

        .how-we-started h2 {
            font-size: 36px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .how-we-started p {
            font-size: 18px;
            line-height: 1.6;
            color: #666;
            margin-bottom: 20px;
        }

        .how-we-started .founders-image {
            max-width: 100%;
            height: auto;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Footer styling */
        .footer {
            background-color: #1c2b2d;
            color: #fff;
            padding: 40px 0;
        }

        .footer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .footer-left, .footer-middle, .footer-right {
            flex: 1;
            margin-bottom: 20px;
            min-width: 250px;
        }

        .footer-left img {
            width: 60px;
            height: 60px;
            margin-bottom: 20px;
            border-radius: 50%;
        }

        .footer-left p {
            margin-bottom: 20px;
            font-size: 14px;
        }

        .subscribe-form {
            display: flex;
            border-radius: 50px;
            overflow: hidden;
        }

        .subscribe-form input {
            padding: 10px;
            border: none;
            outline: none;
            flex-grow: 1;
            border-radius: 50px 0 0 50px;
        }

        .subscribe-form button {
            padding: 10px 20px;
            border: none;
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
            border-radius: 0 50px 50px 0;
            transition: background-color 0.3s ease;
        }

        .subscribe-form button:hover {
            background-color: #388e3c;
        }

        .footer-middle h3, .footer-right h3 {
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: bold;
        }

        .footer-middle ul {
            list-style: none;
            padding: 0;
        }

        .footer-middle ul li {
            margin-bottom: 10px;
        }

        .footer-middle ul li a {
            color: #c4c4c4;
            text-decoration: none;
            font-size: 14px;
        }

        .footer-middle ul li a:hover {
            text-decoration: underline;
            color: #fff;
        }

        .recent-posts {
            list-style: none;
            padding: 0;
        }

        .recent-posts li {
            display: flex;
            margin-bottom: 20px;
        }

        .neon {
        text-shadow: 0 0 10px rgba(255, 255, 0, 0.8), 0 0 20px rgba(255, 255, 0, 0.6), 0 0 30px rgba(255, 255, 0, 0.4);
    }

        .recent-posts img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            margin-right: 10px;
        }

        .recent-posts div {
            flex-grow: 1;
        }

        .recent-posts a {
            color: #c4c4c4;
            text-decoration: none;
            font-size: 14px;
            display: block;
            margin-bottom: 5px;
        }

        .recent-posts a:hover {
            text-decoration: underline;
            color: #fff;
        }

        .recent-posts span {
            font-size: 12px;
            color: #888;
        }

        .footer-right p {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .social-icons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .social-icons a {
            background-color: #4caf50;
            color: #fff;
            padding: 8px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .social-icons a:hover {
            background-color: #388e3c;
        }

        .social-icons a i {
            font-size: 18px;
        }

        .footer-bottom {
            border-top: 1px solid #4caf50;
            padding-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #c4c4c4;
        }

        .footer-bottom p {
            margin: 0;
        }

        .footer-links {
            margin-top: 10px;
        }

        .footer-links a {
            color: #c4c4c4;
            text-decoration: none;
            margin: 0 10px;
            font-size: 14px;
        }

        .footer-links a:hover {
            text-decoration: underline;
            color: #fff;
        }
    </style>
</head>

<body class="bg-white text-gray-800 font-sans">

<!-- Header Section -->
<header class="bg-white shadow-md sticky top-0 z-50">
    <div class="container mx-auto flex justify-between items-center p-4">
        <!-- Logo and Brand Name -->
        <div class="flex items-center space-x-4">
            <img src="KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
            <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms</h1>
        </div>

        <!-- Navigation Links -->
        <nav class="hidden md:flex space-x-6 relative">
            <a href="#" class="text-gray-700 hover:text-green-700 transition duration-200">About Us</a>
            <div class="relative group">
                <a href="shop/shop" class="text-gray-700 hover:text-green-700 transition duration-200">Shop</a>
                <div class="absolute left-0 mt-2 w-48 bg-white shadow-lg border rounded-lg opacity-0 group-hover:opacity-100 transition duration-300 invisible group-hover:visible z-50">
                    <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-green-100 hover:text-green-700 transition">Crop Production</a>
                    <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-green-100 hover:text-green-700 transition">Livestock</a>
                    <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-green-100 hover:text-green-700 transition">Implements</a>
                    <a href="#" class="block px-4 py-2 text-gray-700 hover:bg-green-100 hover:text-green-700 transition">Inputs</a>
                </div>
            </div>
            <a href="#" class="text-gray-700 hover:text-green-700 transition duration-200">Contact</a>
        </nav>

        <!-- User Account and Cart -->
        <div class="flex items-center space-x-6">
            <?php if ($isLoggedIn): ?>
                <!-- Display username and Profile Link if Logged In -->
                <div class="relative group">
                    <!-- Profile Icon and Username -->
                    <div class="flex items-center space-x-2 cursor-pointer">
                        <a href="authentication/profile"><i class="fas fa-user text-2xl text-gray-700"></i></a>
                        <a href="authentication/logout" class="block px-4 py-2 text-red-600 hover:bg-red-100 hover:text-red-700 transition">Log Out</a>
                        <span class="text-green-700 font-medium">Hello, <?= htmlspecialchars($username); ?></span>
                    </div>
                    <!-- Dropdown for Profile and Logout -->
                </div>

                <!-- Cart Icon with Badge -->
                <a href="shop/cart" class="relative">
                    <i class="fas fa-shopping-cart text-gray-700 text-2xl"></i>
                </a>

            <?php else: ?>
                <!-- Login Button if not logged in -->
                <a href="authentication/login">
                    <button class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition duration-200">Login</button>
                </a>
            <?php endif; ?>
        </div>
    </div>
</header>



    <!-- Hero Section -->
    <section class="hero flex flex-col items-center justify-center text-center py-32 relative">
        <!-- Darker Overlay -->
        <div class="absolute inset-0 bg-gradient-to-b from-black/70 to-black/60"></div>
        <div class="relative z-10 px-4 sm:px-6 lg:px-8">
            <h1 class="text-5xl md:text-6xl font-extrabold text-white mb-4 tracking-wide animate-fadeInDown">Keltraken Farms</h1>
            <p class="text-xl md:text-2xl text-white mb-6 animate-fadeInUp">Fresh produce, ready for your table</p>
            <a href="shop/shop" class="bg-green-600 text-white px-8 py-3 rounded-full text-lg hover:bg-green-700 transition duration-300 animate-fadeIn">
                <i class="fas fa-carrot mr-2"></i>Order Now
            </a>
        </div>
    </section>

    <!-- About Us Section -->
    <section class="py-16 bg-gray-50 text-center">
        <div class="container mx-auto px-4">
            <h3 class="text-sm text-green-600 font-semibold">WHAT WE DO</h3>
            <h2 class="text-4xl font-bold mt-2 mb-6 text-gray-900 animate-fadeInDown">Why Choose Our Fresh Foods</h2>
            <p class="text-gray-600 mt-4 max-w-2xl mx-auto animate-fadeInUp">We offer unmatched quality with our fresh and produce. Our farming practices are sustainable, ensuring that you get the best, while supporting the environment.</p>
        </div>
    </section>

    <!-- Products Section -->
<section class="py-16 bg-gray-100">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <!-- Crop Production -->
            <a href="shop/crop_production" class="relative group block">
                <div class="overflow-hidden rounded-lg shadow-lg">
                    <img src="crop_production.webp" alt="Crop Production" class="w-full h-64 object-cover transition-transform duration-300 transform group-hover:scale-105">
                    <div class="p-4 bg-white">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">Crop Production</h3>
                        <p class="text-gray-600">Farming</p>
                    </div>
                </div>
            </a>
            <!-- Livestock -->
            <a href="shop/livestock" class="relative group block">
                <div class="overflow-hidden rounded-lg shadow-lg">
                    <img src="livestock.jpg" alt="Livestock" class="w-full h-64 object-cover transition-transform duration-300 transform group-hover:scale-105">
                    <div class="p-4 bg-white">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">Livestock</h3>
                        <p class="text-gray-600">Pigs, Cattles, Chickens...</p>
                    </div>
                </div>
            </a>
            <!-- Training -->
            <a href="services/training" class="relative group block">
                <div class="overflow-hidden rounded-lg shadow-lg">
                    <img src="training.jpg" alt="Training" class="w-full h-64 object-cover transition-transform duration-300 transform group-hover:scale-105">
                    <div class="p-4 bg-white">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">Training</h3>
                        <p class="text-gray-600">Careers</p>
                    </div>
                </div>
            </a>
            <!-- Implement Input -->
            <a href="shop/implements" class="relative group block">
                <div class="overflow-hidden rounded-lg shadow-lg">
                    <img src="implement_input.jpg" alt="Implement Input" class="w-full h-64 object-cover transition-transform duration-300 transform group-hover:scale-105">
                    <div class="p-4 bg-white">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">Implement</h3>
                        <p class="text-gray-600">Tools</p>
                    </div>
                </div>
            </a>
            <!-- Inputs -->
            <a href="shop/inputs" class="relative group block">
                <div class="overflow-hidden rounded-lg shadow-lg">
                    <img src="input.webp" alt="Inputs" class="w-full h-64 object-cover transition-transform duration-300 transform group-hover:scale-105">
                    <div class="p-4 bg-white">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">Inputs</h3>
                        <p class="text-gray-600">Seeds, Fertilizers, Pesticides...</p>
                    </div>
                </div>
            </a>
        </div>
    </div>
</section>

    <!-- How We Started Section (Dark Green) -->
<section id="how-we-started" class="how-we-started bg-green-800 text-gray-200 py-12">
    <div class="container mx-auto px-6 md:px-12 lg:px-24">
        <div class="text-center">
            <h2 class="text-4xl font-bold text-white mb-6">How We Started</h2>
        </div>
        <div class="md:flex md:items-center md:space-x-8">
            <!-- Text Content -->
            <div class="md:w-2/3">
                <p class="mt-4 text-lg leading-relaxed">
                    Our journey began with a shared passion and vision. We wanted to create something unique, something that would make a difference. It all started with an idea, a dream, and a lot of dedication. From humble beginnings, we have grown to what we are today, but we never forget where we came from.
                </p>
                <p class="mt-4 text-lg leading-relaxed">
                    Every step of the way, we have been driven by our values and commitment to excellence. We've faced challenges, celebrated victories, and learned from every experience. This is our story, and it continues to evolve with every passing day.
                </p>
            </div>

            <!-- Image -->
            <div class="md:w-1/3 mt-8 md:mt-0">
                <img src="images/ceo.JPG" alt="Founders discussing the start of the journey" class="w-full h-auto rounded-lg shadow-lg transform hover:scale-105 transition duration-300">
            </div>
        </div>
    </div>
</section>


    <!-- E-Commerce Section (Dark Green) -->
    <section id="shop" class="py-16 bg-green-800 text-gray-200">
    <div class="container mx-auto">
        <h2 class="text-4xl font-bold text-center text-white mb-10">Shop Our Products</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- PHP loop to display random products from multiple categories -->
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transform transition duration-300">
                        <img src="' . $row["image_url"] . '" alt="' . $row["name"] . '" class="w-full h-64 object-cover">
                        <div class="p-6">
                            <h4 class="font-semibold text-xl text-gray-900">' . $row["name"] . '</h4>
                            <p class="text-gray-700 mt-2 text-sm">' . substr($row["description"], 0, 80) . '...</p>
                            <p class="mt-4 text-green-600 font-bold text-lg">₦' . number_format($row["price"], 2) . '</p>
                            <button class="w-full bg-green-600 text-white px-4 py-2 rounded-md mt-4 hover:bg-green-700 transition duration-300">
                                Add to Cart
                            </button>
                        </div>
                    </div>';
                }
            } else {
                echo '<p class="text-white text-center">No products found</p>';
            }
            ?>
        </div>
    </div>
</section>


    <!-- Neon Social Media Section (Dark Green) -->
<section id="social-media" class="py-16 bg-green-900 text-gray-200">
    <div class="container mx-auto text-center">
        <h2 class="text-4xl font-bold text-center text-white mb-10">Follow Us</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8">
            <!-- Social Icon 1: Facebook -->
            <a href="https://www.facebook.com" target="_blank" class="group">
                <div class="flex justify-center items-center p-8 bg-green-800 rounded-full shadow-lg transform transition duration-300 hover:scale-110">
                    <i class="fab fa-facebook-f text-5xl text-yellow-400 neon group-hover:text-yellow-500"></i>
                </div>
                <p class="mt-4 text-lg font-semibold text-yellow-400 group-hover:text-yellow-500">Facebook</p>
            </a>

            <!-- Social Icon 2: Twitter -->
            <a href="https://www.twitter.com" target="_blank" class="group">
                <div class="flex justify-center items-center p-8 bg-green-800 rounded-full shadow-lg transform transition duration-300 hover:scale-110">
                    <i class="fab fa-twitter text-5xl text-yellow-400 neon group-hover:text-yellow-500"></i>
                </div>
                <p class="mt-4 text-lg font-semibold text-yellow-400 group-hover:text-yellow-500">Twitter</p>
            </a>

            <!-- Social Icon 3: Instagram -->
            <a href="https://www.instagram.com" target="_blank" class="group">
                <div class="flex justify-center items-center p-8 bg-green-800 rounded-full shadow-lg transform transition duration-300 hover:scale-110">
                    <i class="fab fa-instagram text-5xl text-yellow-400 neon group-hover:text-yellow-500"></i>
                </div>
                <p class="mt-4 text-lg font-semibold text-yellow-400 group-hover:text-yellow-500">Instagram</p>
            </a>

            <!-- Social Icon 4: YouTube -->
            <a href="https://www.youtube.com" target="_blank" class="group">
                <div class="flex justify-center items-center p-8 bg-green-800 rounded-full shadow-lg transform transition duration-300 hover:scale-110">
                    <i class="fab fa-youtube text-5xl text-yellow-400 neon group-hover:text-yellow-500"></i>
                </div>
                <p class="mt-4 text-lg font-semibold text-yellow-400 group-hover:text-yellow-500">YouTube</p>
            </a>
        </div>
    </div>
</section>

    <!-- Footer (Dark) -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-left">
                <img src="KELTRAKEN FARMS.jpg" alt="FARMI" class="logo">
                <p>To revolutionize the agribusiness landscape by integrating sustainable practices, fostering innovation,
                and building a resilient agricultural community.</p>
                <form class="subscribe-form">
                    <input type="email" placeholder="Your Email">
                    <button type="submit">Subscribe</button>
                </form>
            </div>

            <div class="footer-right">
                <h3>Contact Info</h3>
                <p>ADDRESS: No 7 Portharcort Cresent, Off Gimbiya street, Area 11, Garki, Abuja.</p>
                <p>EMAIL: info@keltrakenfarms.ng</p>
                <p>PHONE: +234 909 600 0011</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024. by YY Organizations</p>
            <div class="footer-links">
                <a href="#">Terms</a>
                <a href="#">Privacy</a>
                <a href="#">Support</a>
            </div>
        </div>
    </footer>

</body>

<?php
// Close the database connection
$conn->close();
?>

<script>
    // JavaScript for Slideshow
    const slideshow = document.getElementById('slideshow');
    const slides = slideshow.children;
    let currentIndex = 0;

    function showSlide(index) {
        const totalSlides = slides.length;
        if (index >= totalSlides) {
            currentIndex = 0;
        } else if (index < 0) {
            currentIndex = totalSlides - 1;
        } else {
            currentIndex = index;
        }
        slideshow.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    document.getElementById('next').addEventListener('click', () => {
        showSlide(currentIndex + 1);
    });

    document.getElementById('prev').addEventListener('click', () => {
        showSlide(currentIndex - 1);
    });

    // Auto slide every 5 seconds
    setInterval(() => {
        showSlide(currentIndex + 1);
    }, 5000);
</script>


</html>
