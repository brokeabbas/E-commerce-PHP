<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file
include '../connection/db.php';

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: ../authentication/login");
    exit();
}

// Get the logged-in user's ID from the users table
$username = $_SESSION['username'];
$user_query = $conn->prepare("SELECT id FROM users WHERE username = ?");
$user_query->bind_param("s", $username);
$user_query->execute();
$user_result = $user_query->get_result();
$user = $user_result->fetch_assoc();
$user_id = $user['id'];

// Handle updating the quantity of a cart item
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_cart'])) {
    $cart_id = $_POST['cart_id'];
    $quantity = $_POST['quantity'];
    
    if ($quantity > 0) {
        $update_cart = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
        $update_cart->bind_param("iii", $quantity, $cart_id, $user_id);
        $update_cart->execute();
    } else {
        // If the quantity is 0, remove the item from the cart
        $delete_cart_item = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
        $delete_cart_item->bind_param("ii", $cart_id, $user_id);
        $delete_cart_item->execute();
    }
}

// Handle removing an item from the cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remove_item'])) {
    $cart_id = $_POST['cart_id'];
    
    $delete_cart_item = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $delete_cart_item->bind_param("ii", $cart_id, $user_id);
    $delete_cart_item->execute();
}

// Fetch all items in the user's cart
$cart_query = $conn->prepare("
    SELECT cart.id as cart_id, products.id as product_id, products.name, products.price, products.image_url, cart.quantity 
    FROM cart 
    JOIN products ON cart.product_id = products.id 
    WHERE cart.user_id = ?
");
$cart_query->bind_param("i", $user_id);
$cart_query->execute();
$cart_result = $cart_query->get_result();

// Calculate total price
$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart | Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .cart-item img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 0.5rem;
        }
    </style>
</head>

<body class="bg-gray-50 text-gray-800">

    <!-- Header Section -->
    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center p-4">
            <div class="flex items-center space-x-4">
                <img src="../KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
                <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms</h1>
            </div>

            <nav class="hidden md:flex space-x-6">
                <a href="index.html" class="text-gray-700 hover:text-green-700 transition duration-200">Home</a>
                <a href="shop" class="text-gray-700 hover:text-green-700 transition duration-200">Shop</a>
                <a href="about.html" class="text-gray-700 hover:text-green-700 transition duration-200">About Us</a>
            </nav>

            <div class="flex items-center space-x-4">
                <span class="text-green-600">Hello, <?= htmlspecialchars($username); ?></span>
                <a href="cart" class="relative">
                    <i class="fas fa-shopping-cart text-gray-700 text-xl"></i>
                </a>
                <a href="authentication/logout">
                    <button class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                        Log Out
                    </button>
                </a>
            </div>
        </div>
    </header>

    <!-- Main Content Section -->
    <section class="py-16">
        <div class="container mx-auto">
            <h2 class="text-3xl font-bold mb-8">Your Shopping Cart</h2>

            <?php if ($cart_result->num_rows > 0): ?>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <!-- Loop through all items in the cart -->
                        <?php while ($row = $cart_result->fetch_assoc()): 
                            $item_total = $row['price'] * $row['quantity'];
                            $total_price += $item_total;
                        ?>
                            <div class="cart-item bg-gray-100 p-4 rounded-lg shadow-md flex items-center space-x-4">
                                <img src="<?= $row['image_url'] ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="w-20 h-20 object-cover rounded-lg">
                                <div class="flex-grow">
                                    <h4 class="text-lg font-semibold"><?= htmlspecialchars($row['name']) ?></h4>
                                    <p class="text-gray-600">₦<?= number_format($row['price'], 2) ?> / each</p>
                                    <p class="text-gray-700 font-medium">Total: ₦<?= number_format($item_total, 2) ?></p>
                                    <form method="POST" class="mt-2 flex items-center space-x-2">
                                        <input type="hidden" name="cart_id" value="<?= $row['cart_id'] ?>">
                                        <label for="quantity_<?= $row['cart_id'] ?>" class="block text-gray-700 font-semibold">Qty</label>
                                        <input type="number" name="quantity" id="quantity_<?= $row['cart_id'] ?>" value="<?= $row['quantity'] ?>" min="1" class="w-20 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400 transition">
                                        <button type="submit" name="update_cart" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition duration-200">Update</button>
                                        <button type="submit" name="remove_item" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition duration-200">Remove</button>
                                    </form>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>

                    <!-- Display total price -->
                    <div class="mt-6 text-right">
                        <h3 class="text-2xl font-bold">Total: ₦<?= number_format($total_price, 2) ?></h3>
                        <a href="../process/checkout" class="inline-block bg-green-600 text-white px-6 py-3 rounded-lg mt-4 hover:bg-green-700 transition duration-300">Proceed to Checkout</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <p class="text-center text-lg">Your cart is currently empty.</p>
                    <a href="shop" class="block text-center mt-4 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-300">Go to Shop</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-green-800 text-white py-10">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Keltraken Farms. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>

<?php
// Close the database connection
$conn->close();
?>
