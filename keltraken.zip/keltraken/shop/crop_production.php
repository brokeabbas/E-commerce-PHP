<?php
// Include the database connection file
include '../connection/db.php';

// Query to select all products with category_id = 1 (Crop Production)
$sql = "SELECT name, price, description, image_url FROM products WHERE category_id = 1";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crop Productions | Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-gray-50 text-gray-800">

    <!-- Header Section -->
    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center p-4">
            <div class="flex items-center space-x-4">
                <img src="../KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
                <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms</h1>
            </div>
            <nav class="hidden md:flex space-x-6">
                <a href="../index.php" class="text-gray-700 hover:text-green-700 transition duration-200">Home</a>
                <a href="shop.php" class="text-gray-700 hover:text-green-700 transition duration-200">ORDER NOW</a>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero bg-gradient-to-b from-green-700 to-green-900 text-white text-center py-24">
        <div class="container mx-auto">
            <h2 class="text-5xl font-extrabold">Crop Production</h2>
            <p class="mt-4 text-xl">Discover the finest crop products from Keltraken Farms.</p>
        </div>
    </section>

    <!-- Products Section -->
    <section class="py-16">
        <div class="container mx-auto">
            <h3 class="text-4xl font-bold text-center text-gray-800 mb-12">Our Crop Products</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                
                <!-- Loop through the products from the database -->
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo '
                        <div class="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
                            <img src="' . $row["image_url"] . '" alt="' . $row["name"] . '" class="w-full h-48 object-cover">
                            <div class="p-6">
                                <h4 class="font-semibold text-xl text-gray-900">' . $row["name"] . '</h4>
                                <p class="text-gray-600 mt-2 text-sm">' . $row["description"] . '</p>
                                <p class="mt-4 text-green-700 font-bold text-lg">₦' . number_format($row["price"]) . ' /kg</p>
                            </div>
                        </div>';
                    }
                } else {
                    echo '<p class="text-center text-gray-700">No products found</p>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-green-900 text-white py-10">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Keltraken Farms. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>

<?php
// Close the database connection
$conn->close();
?>
