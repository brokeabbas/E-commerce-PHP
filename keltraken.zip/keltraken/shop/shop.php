<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file
include '../connection/db.php';

// Set the number of products to display per page
$items_per_page = 20;

// Get the current page number from the URL, default to 1 if not set
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;

// Get the search input from the URL
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Get the selected category from the URL
$category = isset($_GET['category']) && is_numeric($_GET['category']) ? (int)$_GET['category'] : null;

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $items_per_page;

// Modify the SQL query to include search and category filters
$sql = "SELECT id, name, price, description, image_url 
        FROM products 
        WHERE 1=1"; // Start with a basic query that is always true

if ($search) {
    $sql .= " AND name LIKE ?"; // Append the search filter
}

if ($category) {
    $sql .= " AND category_id = ?"; // Append the category filter
}

$sql .= " LIMIT ? OFFSET ?"; // Pagination

// Prepare the SQL statement to prevent SQL injection
$stmt = $conn->prepare($sql);

// Bind the parameters based on which filters are set
if ($search && $category) {
    $search_param = '%' . $search . '%';
    $stmt->bind_param("siii", $search_param, $category, $items_per_page, $offset);
} elseif ($search) {
    $search_param = '%' . $search . '%';
    $stmt->bind_param("sii", $search_param, $items_per_page, $offset);
} elseif ($category) {
    $stmt->bind_param("iii", $category, $items_per_page, $offset);
} else {
    $stmt->bind_param("ii", $items_per_page, $offset);
}

// Execute the query
$stmt->execute();
$result = $stmt->get_result();

// Query to count the total number of products (considering search and category filter)
$total_items_query = "SELECT COUNT(*) as total FROM products WHERE 1=1";

if ($search) {
    $total_items_query .= " AND name LIKE ?";
}
if ($category) {
    $total_items_query .= " AND category_id = ?";
}

$total_stmt = $conn->prepare($total_items_query);

if ($search && $category) {
    $total_stmt->bind_param("si", $search_param, $category);
} elseif ($search) {
    $total_stmt->bind_param("s", $search_param);
} elseif ($category) {
    $total_stmt->bind_param("i", $category);
}

$total_stmt->execute();
$total_items_result = $total_stmt->get_result();
$total_items_row = $total_items_result->fetch_assoc();
$total_items = $total_items_row['total'];

// Calculate the total number of pages
$total_pages = ceil($total_items / $items_per_page);

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['username']);
$username = $isLoggedIn ? $_SESSION['username'] : null;

// Handle adding to cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    if (!$isLoggedIn) {
        header("Location: ../authentication/login");
        exit();
    }

    // Get the logged-in user's ID from the users table
    $user_query = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $user_query->bind_param("s", $username);
    $user_query->execute();
    $user_result = $user_query->get_result();
    $user = $user_result->fetch_assoc();
    $user_id = $user['id'];

    // Get product ID and quantity from POST data
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Check if the product already exists in the cart
    $cart_check_query = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $cart_check_query->bind_param("ii", $user_id, $product_id);
    $cart_check_query->execute();
    $cart_result = $cart_check_query->get_result();

    if ($cart_result->num_rows > 0) {
        // Update the quantity if the product is already in the cart
        $update_cart = $conn->prepare("UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?");
        $update_cart->bind_param("iii", $quantity, $user_id, $product_id);
        $update_cart->execute();
    } else {
        // Insert a new row if the product is not in the cart
        $insert_cart = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity, added_at) VALUES (?, ?, ?, NOW())");
        $insert_cart->bind_param("iii", $user_id, $product_id, $quantity);
        $insert_cart->execute();
    }

    // Redirect to the cart page
    header("Location: cart");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop | Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        aside.sticky-sidebar {
            position: fixed;
            top: 20px;
            width: 18%;
            max-height: 90vh;
            overflow-y: auto;
            background-color: white;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .main-content {
            margin-left: 22%;
        }

        .product-card:hover {
            transform: translateY(-5px);
            transition: transform 0.3s ease;
        }

        .fade-in {
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 1024px) {
            .main-content {
                margin-left: 0;
            }

            aside.sticky-sidebar {
                display: none;
            }
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const toggleButton = document.getElementById('mobileFilterToggle');
            const filterForm = document.getElementById('mobileFilterForm');

            toggleButton.addEventListener('click', () => {
                filterForm.classList.toggle('hidden');
            });
        });
    </script>
</head>

<body class="bg-gray-100 text-gray-800">

    <!-- Mobile Filter Bar -->
    <div class="bg-white p-4 lg:hidden shadow-md fixed top-0 left-0 right-0 z-50">
        <button id="mobileFilterToggle" class="flex items-center space-x-2 text-gray-700">
            <span>Filter</span>
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
        </button>

        <!-- Mobile Filter Form (Initially Hidden) -->
        <div id="mobileFilterForm" class="hidden mt-4">
            <form method="GET">
                <div class="mb-4">
                    <label for="mobile_search" class="block text-gray-700 font-semibold">Search</label>
                    <input type="text" id="mobile_search" name="search" placeholder="Search products..." class="w-full px-4 py-2 border rounded-lg mt-2" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Categories</label>
                    <button type="submit" name="category" value="" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category === null ? 'bg-green-600 text-white' : '' ?>">All</button>
                    <button type="submit" name="category" value="1" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 1 ? 'bg-green-600 text-white' : '' ?>">Crops</button>
                    <button type="submit" name="category" value="2" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 2 ? 'bg-green-600 text-white' : '' ?>">Livestock</button>
                    <button type="submit" name="category" value="3" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 3 ? 'bg-green-600 text-white' : '' ?>">Implements</button>
                    <button type="submit" name="category" value="4" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 4 ? 'bg-green-600 text-white' : '' ?>">Inputs</button>
                </div>

                <button class="bg-green-600 text-white px-4 py-2 rounded-lg w-full hover:bg-green-700">Apply Filters</button>
            </form>
        </div>
    </div>

    <!-- Header Section -->
    <header class="bg-white shadow-md sticky top-0 z-40">
        <div class="container mx-auto flex justify-between items-center p-4">
            <div class="flex items-center space-x-4">
                <img src="../KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
                <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms</h1>
            </div>

            <nav class="hidden md:flex space-x-6">
                <a href="index.html" class="text-gray-700 hover:text-green-700 transition duration-200">Home</a>
                <a href="about.html" class="text-gray-700 hover:text-green-700 transition duration-200">About Us</a>
                <a href="services.html" class="text-gray-700 hover:text-green-700 transition duration-200">Services</a>
                <a href="contact.html" class="text-gray-700 hover:text-green-700 transition duration-200">Contact</a>
            </nav>

            <div class="flex items-center space-x-4">
                <?php if ($isLoggedIn): ?>
                    <span class="text-green-600">Hello, <?= htmlspecialchars($username); ?></span>
                    <a href="cart" class="relative">
                        <i class="fas fa-shopping-cart text-gray-700"></i>
                        <span class="absolute top-0 right-0 bg-green-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs"></span>
                    </a>
                    <a href="authentication/logout">
                        <button class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                            Log Out
                        </button>
                    </a>
                <?php else: ?>
                    <a href="../authentication/login">
                        <button class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition duration-200">
                            Login
                        </button>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Main Content Section -->
    <section class="py-16 fade-in">
        <div class="container mx-auto flex">

            <!-- Sidebar Filters with Sticky Position for Larger Screens -->
            <aside class="sticky-sidebar p-4 rounded-lg shadow-md bg-white hidden lg:block">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Filter by</h3>
                <form method="GET">
                    <div class="mb-4">
                        <label for="search" class="block text-gray-700 font-semibold">Search</label>
                        <input type="text" id="search" name="search" placeholder="Search products..." class="w-full px-4 py-2 border rounded-lg mt-2" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                    </div>

                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold mb-2">Categories</label>
                        <button type="submit" name="category" value="" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category === null ? 'bg-green-600 text-white' : '' ?>">All</button>
                        <button type="submit" name="category" value="1" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 1 ? 'bg-green-600 text-white' : '' ?>">Crops</button>
                        <button type="submit" name="category" value="2" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 2 ? 'bg-green-600 text-white' : '' ?>">Livestock</button>
                        <button type="submit" name="category" value="3" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 3 ? 'bg-green-600 text-white' : '' ?>">Implements</button>
                        <button type="submit" name="category" value="4" class="bg-gray-200 px-4 py-2 rounded-lg mb-2 <?= $category == 4 ? 'bg-green-600 text-white' : '' ?>">Inputs</button>
                    </div>

                    <button class="bg-green-600 text-white px-4 py-2 rounded-lg w-full hover:bg-green-700">Apply Filters</button>
                </form>
            </aside>

            <!-- Products Grid -->
            <div class="main-content w-full lg:w-3/4 lg:ml-6">
                <h3 class="text-2xl font-bold mb-6">Our Products</h3>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <!-- Loop through all products from the database -->
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo '
                            <div class="bg-white rounded-lg shadow-md overflow-hidden product-card transform transition hover:scale-105 duration-300">
                                <img src="' . $row["image_url"] . '" alt="' . htmlspecialchars($row["name"]) . '" class="w-full h-36 object-cover">
                                <div class="p-4">
                                    <h4 class="font-semibold text-lg">' . htmlspecialchars($row["name"]) . '</h4>
                                    <p class="text-gray-600 mt-2">' . htmlspecialchars($row["description"]) . '</p>
                                    <p class="mt-4 font-bold">₦' . number_format($row["price"], 2) . '</p>
                                    <form method="POST" class="mt-4">
                                        <input type="hidden" name="product_id" value="' . $row["id"] . '">
                                        <label for="quantity_' . $row["id"] . '" class="block text-gray-700 font-semibold">Quantity</label>
                                        <input type="number" name="quantity" id="quantity_' . $row["id"] . '" value="1" min="1" class="w-20 px-4 py-2 border rounded-lg mt-2">
                                        <button type="submit" name="add_to_cart" class="bg-green-600 text-white px-4 py-2 rounded mt-4 hover:bg-green-700">Add to Cart</button>
                                    </form>
                                </div>
                            </div>';
                        }
                    } else {
                        echo '<p>No products available at the moment.</p>';
                    }
                    ?>
                </div>

                <!-- Pagination -->
                <div class="mt-8 flex justify-center">
                    <?php if ($current_page > 1): ?>
                        <a href="?page=<?php echo $current_page - 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>" class="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300">Previous</a>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>" class="px-4 py-2 mx-1 <?php echo ($i == $current_page) ? 'bg-green-600 text-white' : 'bg-gray-200'; ?> rounded-lg hover:bg-gray-300"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    <?php if ($current_page < $total_pages): ?>
                        <a href="?page=<?php echo $current_page + 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>" class="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300">Next</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-green-800 text-white py-10">
        <div class="container mx-auto text-center">
            <p>&copy; YY Organizations. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>

<?php
// Close the database connection
$conn->close();
?>
