<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file
include '../connection/db.php';

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: ../authentication/login");
    exit();
}

// Get the logged-in user's ID from the users table
$username = $_SESSION['username'];
$user_query = $conn->prepare("SELECT id FROM users WHERE username = ?");
$user_query->bind_param("s", $username);
$user_query->execute();
$user_result = $user_query->get_result();
$user = $user_result->fetch_assoc();
$user_id = $user['id'];

// Handle new receipt upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['receipt'])) {
    $order_id = $_POST['order_id'];
    $receipt = $_FILES['receipt'];

    // Ensure the file is valid
    if ($receipt['error'] === UPLOAD_ERR_OK) {
        // Define the new receipt path
        $receipt_path = '../uploads/receipts/' . basename($receipt['name']);

        // Move the uploaded file to the uploads directory
        if (move_uploaded_file($receipt['tmp_name'], $receipt_path)) {
            // Update the orders_master table to store the new receipt path
            $update_query = $conn->prepare("UPDATE orders_master SET receipt_path = ? WHERE order_id = ?");
            $update_query->bind_param("si", $receipt_path, $order_id);
            $update_query->execute();
        }
    }
}

// Get the filter status from the query parameter, default to "all"
$filter_status = isset($_GET['status']) ? $_GET['status'] : 'all';

// Build the SQL query to fetch orders based on the filter
$sql = "
    SELECT orders_master.order_id, orders_master.order_date, orders_master.status, orders_master.receipt_path 
    FROM orders_master 
    WHERE orders_master.user_id = ?";

// If the filter is not "all", add a condition for the status
if ($filter_status !== 'all') {
    $sql .= " AND orders_master.status = ?";
}

// Add the ORDER BY clause to sort by date
$sql .= " ORDER BY orders_master.order_date DESC";

// Prepare the query
$orders_query = $conn->prepare($sql);

// Bind the user_id, and optionally bind the status if filtering
if ($filter_status !== 'all') {
    $orders_query->bind_param("is", $user_id, $filter_status);
} else {
    $orders_query->bind_param("i", $user_id);
}

// Execute the query
$orders_query->execute();
$orders_result = $orders_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders | Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-gray-100 text-gray-800">

    <!-- Header Section -->
    <header class="bg-white shadow sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center p-4">
            <div class="flex items-center space-x-4">
                <img src="../KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
                <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms</h1>
            </div>
            <nav class="hidden md:flex space-x-6">
                <a href="../index" class="text-gray-700 hover:text-green-700 transition duration-200">Home</a>
                <a href="../shop/shop" class="text-gray-700 hover:text-green-700 transition duration-200">Shop</a>
                <a href="about.html" class="text-gray-700 hover:text-green-700 transition duration-200">About Us</a>
            </nav>
            <div class="flex items-center space-x-4">
                <span class="text-green-600">Hello, <?= htmlspecialchars($username); ?></span>
                <a href="cart" class="relative">
                    <i class="fas fa-shopping-cart text-gray-700"></i>
                </a>
                <a href="../authentication/logout">
                    <button class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                        Log Out
                    </button>
                </a>
            </div>
        </div>
    </header>

    <!-- Orders Section -->
    <section class="py-12">
        <div class="container mx-auto">
            <h2 class="text-3xl font-bold mb-8 text-center">My Orders</h2>

            <!-- Filter Section -->
            <div class="flex justify-center space-x-4 mb-8">
                <a href="?status=all" class="px-4 py-2 text-sm font-semibold text-white <?= $filter_status === 'all' ? 'bg-blue-600' : 'bg-gray-400'; ?> rounded hover:bg-blue-700">All</a>
                <a href="?status=pending" class="px-4 py-2 text-sm font-semibold text-white <?= $filter_status === 'pending' ? 'bg-yellow-500' : 'bg-gray-400'; ?> rounded hover:bg-yellow-600">Pending</a>
                <a href="?status=confirmed" class="px-4 py-2 text-sm font-semibold text-white <?= $filter_status === 'confirmed' ? 'bg-green-600' : 'bg-gray-400'; ?> rounded hover:bg-green-700">Confirmed</a>
                <a href="?status=shipping" class="px-4 py-2 text-sm font-semibold text-white <?= $filter_status === 'shipping' ? 'bg-blue-600' : 'bg-gray-400'; ?> rounded hover:bg-blue-700">Shipping</a>
                <a href="?status=delivered" class="px-4 py-2 text-sm font-semibold text-white <?= $filter_status === 'delivered' ? 'bg-purple-600' : 'bg-gray-400'; ?> rounded hover:bg-purple-700">Delivered</a>
            </div>

            <!-- Display user's orders -->
            <?php if ($orders_result->num_rows > 0): ?>
                <div class="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                    <?php while ($order = $orders_result->fetch_assoc()): ?>
                        <div class="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                            <h3 class="text-lg font-bold mb-2">Order #<?= $order['order_id']; ?></h3>
                            <p class="text-sm text-gray-600"><strong>Order Date:</strong> <?= date("F j, Y, g:i a", strtotime($order['order_date'])); ?></p>

                            <!-- Fetch order items for this order -->
                            <?php
                            $order_items_query = $conn->prepare("
                                SELECT products.name, products.price, order_items.quantity 
                                FROM order_items 
                                JOIN products ON order_items.product_id = products.id 
                                WHERE order_items.order_id = ?");
                            $order_items_query->bind_param("i", $order['order_id']);
                            $order_items_query->execute();
                            $order_items_result = $order_items_query->get_result();
                            ?>

                            <h4 class="mt-4 text-sm font-medium">Items in this Order:</h4>
                            <ul class="list-disc ml-5 text-sm text-gray-700">
                                <?php while ($item = $order_items_result->fetch_assoc()): ?>
                                    <li>
                                        <p><strong><?= htmlspecialchars($item['name']); ?></strong></p>
                                        <p>Quantity: <?= $item['quantity']; ?></p>
                                        <p>Price: ₦<?= number_format($item['price'], 2); ?></p>
                                    </li>
                                <?php endwhile; ?>
                            </ul>

                            <!-- Order Status Bar -->
                            <div class="flex justify-between items-center mt-4">
                                <span class="px-3 py-1 text-xs font-semibold text-white rounded-full <?= $order['status'] === 'pending' ? 'bg-yellow-500' : 'bg-gray-300'; ?>">Pending Payment</span>
                                <span class="px-3 py-1 text-xs font-semibold text-white rounded-full <?= $order['status'] === 'confirmed' ? 'bg-green-600' : 'bg-gray-300'; ?>">Payment Confirmed</span>
                                <span class="px-3 py-1 text-xs font-semibold text-white rounded-full <?= $order['status'] === 'shipping' ? 'bg-blue-600' : 'bg-gray-300'; ?>">Shipping</span>
                                <span class="px-3 py-1 text-xs font-semibold text-white rounded-full <?= $order['status'] === 'delivered' ? 'bg-purple-600' : 'bg-gray-300'; ?>">Delivered</span>
                            </div>

                            <!-- Display receipt if uploaded -->
                            <?php if (!empty($order['receipt_path'])): ?>
                                <div class="mt-4">
                                    <p class="text-sm font-medium">Uploaded Receipt:</p>
                                    <a href="<?= htmlspecialchars('../process/' . $order['receipt_path']); ?>" target="_blank" class="text-blue-600 underline text-sm">View Receipt</a>
                                </div>
                            <?php endif; ?>

                            <!-- Upload new receipt form -->
                            <form action="" method="POST" enctype="multipart/form-data" class="mt-4">
                                <input type="hidden" name="order_id" value="<?= $order['order_id']; ?>">
                                <label for="receipt_upload" class="block text-sm font-medium mb-2">Upload New Payment Receipt:</label>
                                <input type="file" name="receipt" id="receipt_upload" class="mb-4 w-full border border-gray-300 p-2 rounded <?= $order['status'] !== 'pending' ? 'bg-gray-200 cursor-not-allowed' : ''; ?>" <?= $order['status'] !== 'pending' ? 'disabled' : ''; ?>>
                                <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition duration-200 <?= $order['status'] !== 'pending' ? 'disabled-button' : ''; ?>">
                                    Upload New Receipt
                                </button>
                            </form>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-center text-gray-700">You have not placed any orders yet.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-green-800 text-white py-6">
        <div class="container mx-auto text-center text-sm">
            <p>&copy; YY Organizations. All Rights Reserved.</p>
        </div>
    </footer>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
