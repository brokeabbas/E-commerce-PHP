<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Include the database connection file
include '../connection/db.php';

// Include PHPMailer classes for sending emails
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../connection/vendor/autoload.php'; // Ensure this is the correct path to the Composer autoload file

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: ../authentication/login");
    exit();
}

// Get the logged-in user's ID from the users table
$username = $_SESSION['username'];
$user_query = $conn->prepare("SELECT id FROM users WHERE username = ?");
$user_query->bind_param("s", $username);
$user_query->execute();
$user_result = $user_query->get_result();
$user = $user_result->fetch_assoc();
$user_id = $user['id'];

// Fetch user's saved address details (if they exist)
$address_query = $conn->prepare("SELECT * FROM user_addresses WHERE user_id = ?");
$address_query->bind_param("i", $user_id);
$address_query->execute();
$address_result = $address_query->get_result();
$address = $address_result->fetch_assoc();

// Define variables to hold address details (default to empty if not available)
$billing_fullname = $address['billing_fullname'] ?? '';
$billing_email = $address['billing_email'] ?? '';
$billing_phone = $address['billing_phone'] ?? '';
$billing_address = $address['billing_address'] ?? '';
$billing_state = $address['billing_state'] ?? '';

$shipping_fullname = $address['shipping_fullname'] ?? '';
$shipping_email = $address['shipping_email'] ?? '';
$shipping_phone = $address['shipping_phone'] ?? '';
$shipping_address = $address['shipping_address'] ?? '';
$shipping_state = $address['shipping_state'] ?? '';

// Handle form submission for confirming payment, uploading receipt, and moving items to orders
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form inputs for billing and shipping addresses
    $billing_fullname = $_POST['billing_fullname'];
    $billing_email = $_POST['billing_email'];
    $billing_phone = $_POST['billing_phone'];
    $billing_address = $_POST['billing_address'];
    $billing_state = $_POST['billing_state'];
    $shipping_fullname = isset($_POST['shipping_fullname']) ? $_POST['shipping_fullname'] : null;
    $shipping_email = isset($_POST['shipping_email']) ? $_POST['shipping_email'] : null;
    $shipping_phone = isset($_POST['shipping_phone']) ? $_POST['shipping_phone'] : null;
    $shipping_address = isset($_POST['shipping_address']) ? $_POST['shipping_address'] : null;
    $shipping_state = isset($_POST['shipping_state']) ? $_POST['shipping_state'] : null;

    // Check if the user already has an address record
    $address_check_query = $conn->prepare("SELECT id FROM user_addresses WHERE user_id = ?");
    $address_check_query->bind_param("i", $user_id);
    $address_check_query->execute();
    $address_result = $address_check_query->get_result();

    if ($address_result->num_rows > 0) {
        // If the user already has an address, update it
        $update_address_query = $conn->prepare("
            UPDATE user_addresses 
            SET billing_fullname = ?, billing_email = ?, billing_phone = ?, billing_address = ?, billing_state = ?, 
                shipping_fullname = ?, shipping_email = ?, shipping_phone = ?, shipping_address = ?, shipping_state = ? 
            WHERE user_id = ?");
        $update_address_query->bind_param(
            "ssssssssssi", 
            $billing_fullname, $billing_email, $billing_phone, $billing_address, $billing_state, 
            $shipping_fullname, $shipping_email, $shipping_phone, $shipping_address, $shipping_state, $user_id
        );
        $update_address_query->execute();
    } else {
        // If the user doesn't have an address, insert a new record
        $insert_address_query = $conn->prepare("
            INSERT INTO user_addresses 
            (user_id, billing_fullname, billing_email, billing_phone, billing_address, billing_state, shipping_fullname, shipping_email, shipping_phone, shipping_address, shipping_state) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insert_address_query->bind_param(
            "issssssssss", 
            $user_id, $billing_fullname, $billing_email, $billing_phone, $billing_address, $billing_state, 
            $shipping_fullname, $shipping_email, $shipping_phone, $shipping_address, $shipping_state
        );
        $insert_address_query->execute();
    }

    // Handle receipt file upload
    $target_dir = "uploads/receipts/";
    
    // Ensure the directory exists, create if not
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Generate a unique file name for the uploaded receipt
    $unique_name = uniqid() . "_" . basename($_FILES["receipt"]["name"]);
    $receipt_file = $target_dir . $unique_name;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($receipt_file, PATHINFO_EXTENSION));

    // Check if file is a valid image or PDF
    $check = getimagesize($_FILES["receipt"]["tmp_name"]);
    if ($check !== false || $imageFileType == "pdf") {
        $uploadOk = 1;
    } else {
        echo "File is not a valid image or PDF.";
        $uploadOk = 0;
    }

    // Check file size (limit to 5MB)
    if ($_FILES["receipt"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Only allow certain file formats (images and PDF)
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "pdf") {
        echo "Sorry, only JPG, JPEG, PNG & PDF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        // Try to upload the file
        if (move_uploaded_file($_FILES["receipt"]["tmp_name"], $receipt_file)) {
            
            // First, create an entry for the order itself (only once for all cart items)
            $insert_order_master_query = $conn->prepare("
                INSERT INTO orders_master (user_id, order_date, receipt_path) 
                VALUES (?, NOW(), ?)");
            $insert_order_master_query->bind_param("is", $user_id, $receipt_file);
            $insert_order_master_query->execute();
            
            // Get the generated order ID
            $order_id = $insert_order_master_query->insert_id;

            // Fetch all items in the user's cart
            $cart_query = $conn->prepare("
                SELECT cart.id as cart_id, products.id as product_id, cart.quantity 
                FROM cart 
                JOIN products ON cart.product_id = products.id 
                WHERE cart.user_id = ?");
            $cart_query->bind_param("i", $user_id);
            $cart_query->execute();
            $cart_result = $cart_query->get_result();

            // Move cart items to order_items table and then delete from cart
            while ($row = $cart_result->fetch_assoc()) {
                // Insert each cart item into order_items table
                $insert_order_item_query = $conn->prepare("
                    INSERT INTO order_items (order_id, product_id, quantity) 
                    VALUES (?, ?, ?)");
                $insert_order_item_query->bind_param("iii", $order_id, $row['product_id'], $row['quantity']);
                $insert_order_item_query->execute();

                // Delete the cart item
                $delete_cart_query = $conn->prepare("DELETE FROM cart WHERE id = ?");
                $delete_cart_query->bind_param("i", $row['cart_id']);
                $delete_cart_query->execute();
            }

            // Store the total amount in the session for later use in the email
            $_SESSION['total_price'] = $total_price;

            // Send Payment Confirmation Emails
            sendConfirmationEmail($billing_email, $shipping_email, $receipt_file);
            sendAdminOrderEmail($user_id, $billing_fullname, $billing_email, $total_price);

            // Redirect to orders page after successful payment
            header("Location: orders");
            exit();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

// Function to send the confirmation email to the customer
function sendConfirmationEmail($billing_email, $shipping_email, $receipt_file) {
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();                                           
        $mail->Host       = 'mail.keltrakenfarms.ng';               
        $mail->SMTPAuth   = true;                                  
        $mail->Username   = 'orders@keltrakenfarms.ng';             
        $mail->Password   = 'NL-wJVXbR@&y';             
        $mail->SMTPSecure = 'ssl';                                 
        $mail->Port       = 465;                                   

        //Recipients
        $mail->setFrom('orders@keltrakenfarms.ng', 'Keltraken Farms');
        $mail->addAddress($billing_email);     
        if ($shipping_email) {
            $mail->addAddress($shipping_email);  
        }

        // Attach receipt if available
        $mail->addAttachment($receipt_file);   

        // Content
        $mail->isHTML(true);                                 
        $mail->Subject = 'Payment Receipt for Your Order';
        
        // Retrieve total price from session
        $total_price = isset($_SESSION['total_price']) ? $_SESSION['total_price'] : 0;

        // Create the email body
        $mail->Body    = "<p>Thank you for your payment. We will confirm your payment and get back to you shortly or before 24 hours.</p>";

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

// Function to send the order notification email to the admin
function sendAdminOrderEmail($user_id, $billing_fullname, $billing_email, $total_price) {
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();                                           
        $mail->Host       = 'mail.keltrakenfarms.ng';               
        $mail->SMTPAuth   = true;                                  
        $mail->Username   = 'orders@keltrakenfarms.ng';             
        $mail->Password   = 'NL-wJVXbR@&y';             
        $mail->SMTPSecure = 'ssl';                                 
        $mail->Port       = 465;                                   

        //Recipients
        $mail->setFrom('orders@keltrakenfarms.ng', 'Keltraken Farms');
        $mail->addAddress('orders@keltrakenfarms.ng'); // Admin email

        // Content
        $mail->isHTML(true);                                 
        $mail->Subject = 'New Order Received - Order #'.$user_id;
        
        // Create the email body for admin
        $mail->Body = "
            <p>A new order has been placed by <strong>$billing_fullname</strong> (Email: $billing_email).</p>
            <p>Total Order Amount: ₦".number_format($total_price, 2)."</p>
            <p>Please log in to the admin dashboard to view further details.</p>
        ";

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent to admin. Mailer Error: {$mail->ErrorInfo}";
    }
}

// Fetch the total price of the cart items
$cart_query = $conn->prepare("
    SELECT products.price, cart.quantity 
    FROM cart 
    JOIN products ON cart.product_id = products.id 
    WHERE cart.user_id = ?");
$cart_query->bind_param("i", $user_id);
$cart_query->execute();
$cart_result = $cart_query->get_result();

$total_price = 0;
while ($row = $cart_result->fetch_assoc()) {
    $total_price += $row['price'] * $row['quantity'];
}

// Store the total price in session
$_SESSION['total_price'] = $total_price;
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | Keltraken Farms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-gray-100 text-gray-800">

    <!-- Header Section -->
    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center p-4">
            <div class="flex items-center space-x-4">
                <img src="../KELTRAKEN FARMS.jpg" alt="Logo" class="w-12 h-12 rounded-full">
                <h1 class="text-2xl font-semibold text-green-700">Keltraken Farms</h1>
            </div>
            <nav class="hidden md:flex space-x-6">
                <a href="index.html" class="text-gray-700 hover:text-green-700 transition duration-200">Home</a>
                <a href="shop" class="text-gray-700 hover:text-green-700 transition duration-200">Shop</a>
                <a href="about.html" class="text-gray-700 hover:text-green-700 transition duration-200">About Us</a>
            </nav>
            <div class="flex items-center space-x-4">
                <span class="text-green-600">Hello, <?= htmlspecialchars($username); ?></span>
                <a href="cart" class="relative">
                    <i class="fas fa-shopping-cart text-gray-700 text-xl"></i>
                </a>
                <a href="authentication/logout">
                    <button class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                        Log Out
                    </button>
                </a>
            </div>
        </div>
    </header>

    <!-- Main Content Section -->
    <section class="py-16">
        <div class="container mx-auto">
            <h2 class="text-3xl font-bold mb-6">Checkout</h2>

            <!-- Nigerian Bank Account Details -->
            <div class="checkout-details bg-white p-6 rounded-lg shadow-lg mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="account-info">
                    <h3 class="text-xl font-semibold">Transfer to:</h3>
                    <p class="text-gray-700 mt-2">Bank Name: <strong>Guaranty Trust Bank PLC</strong></p>
                    <p class="text-gray-700 mt-2">Account Name: <strong>Keltraken Integrated Services Limited</strong></p>
                    <p class="text-gray-700 mt-2">Account Number: <strong>0915228075</strong></p>
                </div>
                <div class="total-info text-right md:text-left">
                    <h3 class="text-xl font-semibold">Total Payment:</h3>
                    <p class="text-green-600 text-2xl mt-2"><strong>₦<?= number_format($total_price, 2) ?></strong></p>
                </div>
            </div>

            <!-- Billing and Shipping Address Form -->
            <div class="address-section bg-white p-6 rounded-lg shadow-lg">
                <form method="POST" enctype="multipart/form-data">
                    <h3 class="text-lg font-semibold mb-4">Billing and Shipping Address</h3>

                    <!-- Billing Address -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="billing_fullname" class="block font-medium text-gray-700">Billing Full Name</label>
                            <input type="text" name="billing_fullname" id="billing_fullname" value="<?= htmlspecialchars($billing_fullname); ?>" placeholder="John Doe" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label for="billing_email" class="block font-medium text-gray-700">Billing Email</label>
                            <input type="email" name="billing_email" id="billing_email" value="<?= htmlspecialchars($billing_email); ?>" placeholder="johndoe@example.com" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label for="billing_phone" class="block font-medium text-gray-700">Billing Phone Number</label>
                            <input type="tel" name="billing_phone" id="billing_phone" value="<?= htmlspecialchars($billing_phone); ?>" placeholder="+234 1234567890" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label for="billing_address" class="block font-medium text-gray-700">Billing Address</label>
                            <textarea name="billing_address" id="billing_address" rows="3" placeholder="123 Street Name, Lagos, Nigeria" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"><?= htmlspecialchars($billing_address); ?></textarea>
                        </div>

                        <div>
                            <label for="billing_state" class="block font-medium text-gray-700">State</label>
                            <select name="billing_state" id="billing_state" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                                <option value="">Select State</option>
                                <option value="Lagos" <?= $billing_state === 'Lagos' ? 'selected' : ''; ?>>Lagos</option>
                                <option value="Abuja" <?= $billing_state === 'Abuja' ? 'selected' : ''; ?>>Abuja</option>
                                <option value="Rivers" <?= $billing_state === 'Rivers' ? 'selected' : ''; ?>>Rivers</option>
                                <option value="Kano" <?= $billing_state === 'Kano' ? 'selected' : ''; ?>>Kano</option>
                            </select>
                        </div>
                    </div>

                    <!-- Shipping Address -->
                    <h3 class="text-lg font-semibold mt-8">Shipping Address (If different)</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                        <div>
                            <label for="shipping_fullname" class="block font-medium text-gray-700">Shipping Full Name</label>
                            <input type="text" name="shipping_fullname" id="shipping_fullname" value="<?= htmlspecialchars($shipping_fullname); ?>" placeholder="Jane Doe" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label for="shipping_email" class="block font-medium text-gray-700">Shipping Email</label>
                            <input type="email" name="shipping_email" id="shipping_email" value="<?= htmlspecialchars($shipping_email); ?>" placeholder="janedoe@example.com" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label for="shipping_phone" class="block font-medium text-gray-700">Shipping Phone Number</label>
                            <input type="tel" name="shipping_phone" id="shipping_phone" value="<?= htmlspecialchars($shipping_phone); ?>" placeholder="+234 9876543210" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label for="shipping_address" class="block font-medium text-gray-700">Shipping Address</label>
                            <textarea name="shipping_address" id="shipping_address" rows="3" placeholder="123 Street Name, Lagos, Nigeria" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"><?= htmlspecialchars($shipping_address); ?></textarea>
                        </div>

                        <div>
                            <label for="shipping_state" class="block font-medium text-gray-700">State</label>
                            <select name="shipping_state" id="shipping_state" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                                <option value="">Select State</option>
                                <option value="Lagos" <?= $shipping_state === 'Lagos' ? 'selected' : ''; ?>>Lagos</option>
                                <option value="Abuja" <?= $shipping_state === 'Abuja' ? 'selected' : ''; ?>>Abuja</option>
                                <option value="Rivers" <?= $shipping_state === 'Rivers' ? 'selected' : ''; ?>>Rivers</option>
                                <option value="Kano" <?= $shipping_state === 'Kano' ? 'selected' : ''; ?>>Kano</option>
                            </select>
                        </div>
                    </div>

                    <!-- Receipt Upload Area -->
                    <div class="receipt-upload-area mt-8">
                        <label for="receipt" class="block font-medium text-gray-700">Upload your payment receipt</label>
                        <input type="file" name="receipt" id="receipt" accept=".jpg, .jpeg, .png, .pdf" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                    </div>

                    <!-- Confirm Payment Button -->
                    <div class="text-center mt-8">
                        <button type="submit" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-300">
                            Confirm Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-green-800 text-white py-10">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Keltraken Farms. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>


<?php
// Close the database connection
$conn->close();
?>
