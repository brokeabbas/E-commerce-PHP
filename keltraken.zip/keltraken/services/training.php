<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Training Registration</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold text-center mb-6">Register for Agricultural Training</h1>

        <form action="#" method="POST" class="space-y-6">
            <!-- Training Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                
                <!-- Advanced Agribusiness -->
                <label for="advanced_agribusiness" class="cursor-pointer">
                    <input type="radio" name="training" id="advanced_agribusiness" value="Advanced Agribusiness" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?agribusiness" alt="Advanced Agribusiness" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Advanced Agribusiness</h2>
                            <p class="text-gray-600 mt-2">Learn advanced strategies in agribusiness development.</p>
                        </div>
                    </div>
                </label>

                <!-- Agricultural Value Chain -->
                <label for="agricultural_value_chain" class="cursor-pointer">
                    <input type="radio" name="training" id="agricultural_value_chain" value="Agricultural Value Chain" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?farming" alt="Agricultural Value Chain" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Agricultural Value Chain</h2>
                            <p class="text-gray-600 mt-2">Gain insights into agricultural value chain processes.</p>
                        </div>
                    </div>
                </label>

                <!-- Agricultural Leadership Development -->
                <label for="agricultural_leadership" class="cursor-pointer">
                    <input type="radio" name="training" id="agricultural_leadership" value="Agricultural Leadership Development" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?leadership" alt="Agricultural Leadership" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Agricultural Leadership Development</h2>
                            <p class="text-gray-600 mt-2">Develop leadership skills tailored for agriculture.</p>
                        </div>
                    </div>
                </label>

                <!-- Crop Production -->
                <label for="crop_production" class="cursor-pointer">
                    <input type="radio" name="training" id="crop_production" value="Crop Production" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?crop" alt="Crop Production" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Crop Production</h2>
                            <p class="text-gray-600 mt-2">Learn best practices in crop production for high yields.</p>
                        </div>
                    </div>
                </label>

                <!-- Livestock Production -->
                <label for="livestock_production" class="cursor-pointer">
                    <input type="radio" name="training" id="livestock_production" value="Livestock Production" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?livestock" alt="Livestock Production" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Livestock Production</h2>
                            <p class="text-gray-600 mt-2">Master livestock production techniques and management.</p>
                        </div>
                    </div>
                </label>

                <!-- Agribusiness Finance -->
                <label for="agribusiness_finance" class="cursor-pointer">
                    <input type="radio" name="training" id="agribusiness_finance" value="Agribusiness Finance" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?finance" alt="Agribusiness Finance" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Agribusiness Finance</h2>
                            <p class="text-gray-600 mt-2">Understand the financial aspects of agribusiness.</p>
                        </div>
                    </div>
                </label>

                <!-- Risk Management -->
                <label for="risk_management" class="cursor-pointer">
                    <input type="radio" name="training" id="risk_management" value="Risk Management" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?risk" alt="Risk Management" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Risk Management</h2>
                            <p class="text-gray-600 mt-2">Learn strategies to manage risk in agribusiness.</p>
                        </div>
                    </div>
                </label>

                <!-- Project Management -->
                <label for="project_management" class="cursor-pointer">
                    <input type="radio" name="training" id="project_management" value="Project Management" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?project" alt="Project Management" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Project Management</h2>
                            <p class="text-gray-600 mt-2">Master project management in agricultural contexts.</p>
                        </div>
                    </div>
                </label>

                <!-- Animal Feed Production -->
                <label for="animal_feed_production" class="cursor-pointer">
                    <input type="radio" name="training" id="animal_feed_production" value="Animal Feed Production" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?feed" alt="Animal Feed Production" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Animal Feed Production</h2>
                            <p class="text-gray-600 mt-2">Understand the essentials of producing animal feed.</p>
                        </div>
                    </div>
                </label>

                <!-- Agribusiness Marketing Management -->
                <label for="agribusiness_marketing" class="cursor-pointer">
                    <input type="radio" name="training" id="agribusiness_marketing" value="Agribusiness Marketing Management" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?marketing" alt="Agribusiness Marketing" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Agribusiness Marketing Management</h2>
                            <p class="text-gray-600 mt-2">Develop marketing strategies for agricultural products.</p>
                        </div>
                    </div>
                </label>

                <!-- Agricultural Mechanization -->
                <label for="agricultural_mechanization" class="cursor-pointer">
                    <input type="radio" name="training" id="agricultural_mechanization" value="Agricultural Mechanization" class="hidden peer">
                    <div class="bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 peer-checked:ring-2 peer-checked:ring-indigo-600">
                        <img src="https://source.unsplash.com/random/400x300?mechanization" alt="Agricultural Mechanization" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h2 class="text-lg font-bold">Agricultural Mechanization</h2>
                            <p class="text-gray-600 mt-2">Explore modern machinery and technologies in agriculture.</p>
                        </div>
                    </div>
                </label>
            </div>

            <!-- Submit Button -->
            <div class="text-center">
                <button type="submit" class="bg-indigo-600 text-white font-bold py-2 px-6 rounded-md hover:bg-indigo-700 transition">
                    Register
                </button>
            </div>
        </form>
    </div>
</body>
</html>
